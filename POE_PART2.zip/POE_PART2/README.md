# POE\_PART2 - QuickChat: Sending Messages

## Folder structure

```
POE\_PART2/
├── pom.xml                          (Maven file - lets your IDE run the tests)
├── README.md
└── src/
    ├── main/java/
    │   ├── Main.java                (run this - the menu application)
    │   ├── Message.java             (the Message class)
    │   └── Login.java               (register / login)
    └── test/java/
        └── MessageTest.java         (unit tests using the test data)
```

## Message class methods (names as in the document)

|Method|What it does|
|-|-|
|`Boolean checkMessageID()`|ID is not more than 10 characters|
|`String checkRecipientCell()`|Starts with an international code (+), digits only, number max 10 digits|
|`String createMessageHash()`|e.g. `00:0:HITONIGHT`|
|`String SentMessage(int choice)`|1 = send, 2 = disregard, 3 = store|
|`String printMessages()`|All messages sent while the program runs|
|`int returnTotalMessagess()`|Total messages sent|
|`void storeMessage()`|Saves messages into `storedMessages.json`|



