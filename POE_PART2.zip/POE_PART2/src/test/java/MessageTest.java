import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * Unit tests that use the test data from the document.
 
 */
public class MessageTest {

    private static final String TEXT_1 = "Hi Mike, can you join us for dinner tonight?";
    private static final String TEXT_2 = "Hi Keegan, did you receive the payment?";

    private Message message1;
    private Message message2;

    @TempDir
    Path tempFolder;

    @BeforeEach
    public void setUp() {
        // Start fresh and write the JSON file into a temporary folder
        Message.resetAll(tempFolder.resolve("storedMessages.json").toString());

        message1 = new Message("0012345678", 0, "+27718693002", TEXT_1);
        message2 = new Message("1234567890", 1, "08575975889", TEXT_2);
    }

    // ---------- Message length ----------
    @Test
    public void testMessageLengthSuccess() {
        assertEquals("Message ready to send.", message1.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        String longText = "a".repeat(260);   // 10 characters too many
        Message longMessage = new Message("0012345678", 0, "+27718693002", longText);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.",
                longMessage.checkMessageLength());
    }

    // ---------- Recipient number ----------
    @Test
    public void testRecipientSuccess() {
        assertEquals("Cell phone number successfully captured.", message1.checkRecipientCell());
    }

    @Test
    public void testRecipientFailure() {
        assertEquals("Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.",
                message2.checkRecipientCell());
    }

    // ---------- Message hash ----------
    @Test
    public void testMessageHashTestCase1() {
        assertEquals("00:0:HITONIGHT", message1.createMessageHash());
    }

    @Test
    public void testRemainingMessageHashesInLoop() {
        Message[] messages = {message1, message2};
        String[] expectedHashes = {"00:0:HITONIGHT", "12:1:HIPAYMENT"};

        for (int i = 0; i < messages.length; i++) {
            assertEquals(expectedHashes[i], messages[i].createMessageHash());
        }
    }

    // ---------- Message ID ----------
    @Test
    public void testMessageIDIsCreated() {
        Message generated = new Message(0, "+27718693002", TEXT_1);

        assertEquals("Message ID generated: " + generated.getMessageID(), generated.getMessageIDText());
        assertEquals(10, generated.getMessageID().length());
        assertTrue(generated.getMessageID().matches("[0-9]{10}"));
        assertTrue(generated.checkMessageID());
    }

    // ---------- SentMessage (send / disregard / store) ----------
    @Test
    public void testSentMessageSend() {
        assertEquals("Message successfully sent.", message1.SentMessage(1));
    }

    @Test
    public void testSentMessageDisregard() {
        assertEquals("Press 0 to delete the message.", message2.SentMessage(2));
    }

    @Test
    public void testSentMessageStore() throws Exception {
        assertEquals("Message successfully stored.", message1.SentMessage(3));

        // The message must have been written to the JSON file
        Path jsonFile = tempFolder.resolve("storedMessages.json");
        assertTrue(Files.exists(jsonFile));
        String content = Files.readString(jsonFile);
        assertTrue(content.contains("00:0:HITONIGHT"));
        assertTrue(content.contains("+27718693002"));
    }

    // ---------- Total messages sent (message 1 sent, message 2 discarded) ----------
    @Test
    public void testReturnTotalMessagess() {
        message1.SentMessage(1);   // Send
        message2.SentMessage(2);   // Discard

        assertEquals(1, Message.returnTotalMessagess());
    }

    @Test
    public void testPrintMessages() {
        message1.SentMessage(1);

        String printed = Message.printMessages();
        assertTrue(printed.contains("Message ID: 0012345678"));
        assertTrue(printed.contains("Message Hash: 00:0:HITONIGHT"));
        assertTrue(printed.contains("Recipient: +27718693002"));
        assertTrue(printed.contains("Message: " + TEXT_1));
    }
}
