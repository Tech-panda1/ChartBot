
public class Login {

    private String username = "";
    private String password = "";
    private boolean registered = false;

    // Registers a new user. Returns true if the details are valid.
    public boolean registerUser(String newUsername, String newPassword) {
        if (newUsername == null || newUsername.trim().isEmpty()) {
            return false;
        }
        if (newPassword == null || newPassword.trim().isEmpty()) {
            return false;
        }
        username = newUsername.trim();
        password = newPassword;
        registered = true;
        return true;
    }

    // Returns true only if the user is registered and the details match.
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        if (!registered) {
            return false;
        }
        return username.equals(enteredUsername.trim()) && password.equals(enteredPassword);
    }

    public String getUsername() {
        return username;
    }
}
