import java.util.Scanner;

/**
 * QuickChat - Part 2: Sending Messages
 */
public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();

       
        // ---------- Welcome message ----------
        System.out.println("Welcome to QuickChat");

        
        // --- Main menu ---
        boolean running = true;
        while (running) {
            System.out.println();
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            int option = readNumber(input, "Choose an option: ");

            
            
            // ---------- How many messages will be entered ----------
        int maxMessages = 0;
        while (maxMessages < 1) {
            maxMessages = readNumber(input, "How many messages do you wish to enter? ");
            if (maxMessages < 1) {
                System.out.println("Please enter a number greater than 0.");
            }
        }

        int messagesEntered = 0;   // counts every message that was entered (sent, stored or disregarded)

            
            if (option == 1) {

                if (messagesEntered >= maxMessages) {
                    System.out.println("You have already entered all " + maxMessages + " messages.");
                }

                while (messagesEntered < maxMessages) {
                    System.out.println();
                    System.out.println("--- Message " + (messagesEntered + 1) + " of " + maxMessages + " ---");

                    // Recipient: repeat until the number is valid
                    Message message = null;
                    boolean cellOk = false;
                    while (!cellOk) {
                        System.out.print("Enter the recipient cell number: ");
                        String recipient = input.nextLine().trim();

                        message = new Message(messagesEntered, recipient, "");
                        String cellResult = message.checkRecipientCell();
                        System.out.println(cellResult);
                        cellOk = cellResult.equals(Message.CELL_OK);
                    }

                    // Message text: repeat until it is not longer than 250 characters
                    boolean lengthOk = false;
                    while (!lengthOk) {
                        System.out.print("Enter your message: ");
                        String text = input.nextLine().trim();

                        if (text.isEmpty()) {
                            System.out.println("The message cannot be empty.");
                            continue;
                        }

                        message.setMessageText(text);
                        String lengthResult = message.checkMessageLength();
                        if (lengthResult.equals(Message.LENGTH_OK)) {
                            lengthOk = true;
                            System.out.println(lengthResult);
                        } else {
                            System.out.println("Please enter a message of less than 250 characters.");
                            System.out.println(lengthResult);
                        }
                    }

                    // Send, disregard or store
                    int choice = 0;
                    while (choice < 1 || choice > 3) {
                        System.out.println("1) Send Message");
                        System.out.println("2) Disregard Message");
                        System.out.println("3) Store Message to send later");
                        choice = readNumber(input, "Choose an option: ");
                    }

                    System.out.println(message.SentMessage(choice));

                    if (choice == 1) {
                        System.out.println();
                        System.out.println(message.getMessageDetails());
                    } else if (choice == 2) {
                        int zero = -1;
                        while (zero != 0) {
                            zero = readNumber(input, "");
                            if (zero != 0) {
                                System.out.println(Message.MSG_DISREGARD);
                            }
                        }
                        System.out.println("Message deleted.");
                    }

                    messagesEntered++;
                }

                // All messages have been entered: show them and the total
                System.out.println();
                System.out.println("===== Messages sent =====");
                System.out.println(Message.printMessages());
                System.out.println("Total messages sent: " + Message.returnTotalMessagess());

            } else if (option == 2) {
                System.out.println("Coming Soon.");

            } else if (option == 3) {
                System.out.println("Total messages sent: " + Message.returnTotalMessagess());
                System.out.println("Goodbye!");
                running = false;

            } else {
                System.out.println("Invalid option. Please choose 1, 2 or 3.");
            }
        }

        input.close();
    }

    // Reads a whole number from the user and keeps asking if they type something else.
    private static int readNumber(Scanner input, String question) {
        while (true) {
            System.out.print(question);
            String line = input.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
