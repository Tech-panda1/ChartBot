import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

/*Message class for QuickChat.*/
public class Message {

    // ---------- Text that the document says must be displayed ----------
    public static final String LENGTH_OK = "Message ready to send.";
    public static final String CELL_OK = "Cell phone number successfully captured.";
    public static final String CELL_ERROR = "Cell phone number is incorrectly formatted " + "or does not contain an international code. Please correct the number and try again.";
    public static final String MSG_SENT = "Message successfully sent.";
    public static final String MSG_DISREGARD = "Press 0 to delete the message.";
    public static final String MSG_STORED = "Message successfully stored.";

    public static final int MAX_MESSAGE_LENGTH = 250;

    // ---------- Shared (static) data ----------
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static ArrayList<Message> storedMessages = new ArrayList<>();
    private static int numMessagesSent = 0;            // starts at 0, goes up by 1 for every sent message
    private static String storageFile = "storedMessages.json";
    private static Random random = new Random();

    // ---------- Data for this one message ----------
    private String messageID;       // ten digits, kept as text so a leading 0 is not lost
    private int messageNumber;      // 0 for the first message, 1 for the second, ...
    private String recipient;
    private String messageText;

    // Constructor that auto-generates the ten-digit Message ID.
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
    }

    // Constructor where the Message ID is supplied (useful for unit tests).
    public Message(String messageID, int messageNumber, String recipient, String messageText) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
    }

    // ---------- Required methods ----------

    // Makes sure the message ID is not more than ten characters.
    public Boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    
    // The number must start with an international code (a + sign), contain only
    public String checkRecipientCell() {
        if (recipient == null || !recipient.startsWith("+")) {
            return CELL_ERROR;
        }

        String digits = recipient.substring(1);   // everything after the +
        if (digits.length() < 10 || digits.length() > 13) {
            return CELL_ERROR;
        }

        for (int i = 0; i < digits.length(); i++) {
            if (!Character.isDigit(digits.charAt(i))) {
                return CELL_ERROR;
            }
        }
        return CELL_OK;
    }

    
    // Format: first two digits of ID : message number : FIRSTWORD + LASTWORD (all caps)
    public String createMessageHash() {
        String firstTwo = messageID.substring(0, 2);

        String[] words = messageText.trim().split("\\s+");
        String firstWord = cleanWord(words[0]);
        String lastWord = cleanWord(words[words.length - 1]);

        String hash = firstTwo + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }

    
    // choice 1 = Send, 2 = Disregard, 3 = Store to send later
    public String SentMessage(int choice) {
        if (choice == 1) {
            sentMessages.add(this);
            numMessagesSent++;
            return MSG_SENT;
        } else if (choice == 2) {
            return MSG_DISREGARD;
        } else if (choice == 3) {
            storeMessage();
            return MSG_STORED;
        }
        return "Invalid choice. Please choose 1, 2 or 3.";
    }

    
    // Returns every message sent while the program is running.
    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }

        String all = "";
        for (int i = 0; i < sentMessages.size(); i++) {
            all = all + sentMessages.get(i).getMessageDetails() + "\n";
        }
        return all;
    }

    
    // Returns the total number of messages sent.
    public static int returnTotalMessagess() {
        return numMessagesSent;
    }

    
    // Saves all stored messages into a JSON file.
    public void storeMessage() {
        storedMessages.add(this);

        String json = "[\n";
        for (int i = 0; i < storedMessages.size(); i++) {
            Message m = storedMessages.get(i);
            json = json + "  {\n";
            json = json + "    \"messageID\": \"" + escapeJson(m.messageID) + "\",\n";
            json = json + "    \"messageHash\": \"" + escapeJson(m.createMessageHash()) + "\",\n";
            json = json + "    \"recipient\": \"" + escapeJson(m.recipient) + "\",\n";
            json = json + "    \"message\": \"" + escapeJson(m.messageText) + "\"\n";
            json = json + "  }";
            if (i < storedMessages.size() - 1) {
                json = json + ",";
            }
            json = json + "\n";
        }
        json = json + "]\n";

        try (FileWriter writer = new FileWriter(storageFile)) {
            writer.write(json);
        } catch (IOException e) {
            System.out.println("Could not save the message to the JSON file: " + e.getMessage());
        }
    }

    // ---------- Extra helper methods ----------

    // Checks the 250-character limit and returns the matching text from the document.
    public String checkMessageLength() {
        int length = messageText.length();
        if (length <= MAX_MESSAGE_LENGTH) {
            return LENGTH_OK;
        }
        int extra = length - MAX_MESSAGE_LENGTH;
        return "Message exceeds 250 characters by " + extra + "; please reduce the size.";
    }

    // Generates a random ten-digit Message ID (as text).
    public static String generateMessageID() {
        String id = "";
        for (int i = 0; i < 10; i++) {
            id = id + random.nextInt(10);
        }
        return id;
    }

    // Text used when the Message ID is created: "Message ID generated: <Message ID>"
    public String getMessageIDText() {
        return "Message ID generated: " + messageID;
    }

    // Full details in the required order: Message ID, Message Hash, Recipient, Message.
    public String getMessageDetails() {
        return "Message ID: " + messageID + "\n"
                + "Message Hash: " + createMessageHash() + "\n"
                + "Recipient: " + recipient + "\n"
                + "Message: " + messageText;
    }

    // Removes anything that is not a letter or number, e.g. "tonight?" becomes "tonight".
    private String cleanWord(String word) {
        return word.replaceAll("[^A-Za-z0-9]", "");
    }

    // Makes text safe to place inside a JSON string.
    private String escapeJson(String text) {
        return text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }

    // Used by the unit tests so every test starts fresh and does not write to the real file.
    public static void resetAll(String newStorageFile) {
        sentMessages.clear();
        storedMessages.clear();
        numMessagesSent = 0;
        storageFile = newStorageFile;
    }

    // ---------- Getters and setters ----------
    public String getMessageID() {
        return messageID;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public String getMessageHash() {
        return createMessageHash();
    }
}
